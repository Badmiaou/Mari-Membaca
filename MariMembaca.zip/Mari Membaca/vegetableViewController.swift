//
//  vegetableViewController.swift
//  Mari Membaca
//
//  Created by Mohammad Rahimyarza Bagagarsyah on 07/06/18.
//  Copyright © 2018 Mohammad Rahimyarza Bagagarsyah. All rights reserved.
//

import UIKit
import AVFoundation

class vegetableViewController: UIViewController {

    @IBOutlet weak var letterLabel: UILabel!
    var audioPlayer = AVAudioPlayer()
    var audioPlayer1 = AVAudioPlayer()
    var audioPlayer2 = AVAudioPlayer()
    override func viewDidLoad() {
        super.viewDidLoad()
        letterLabel.text = ""

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func terongButton(_ sender: Any) {
        letterLabel.text = "TERONG"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "TER", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "ONG", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "TERONG", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }

    
    

    @IBAction func kentangButton(_ sender: Any) {
        letterLabel.text = "KENTANG"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "KEN", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "TANG", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "KENTANG", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
}

    
    
    @IBAction func jamurButton(_ sender: Any) {
        letterLabel.text = "JAMUR"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "JA", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "MUR", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "JAMUR", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    
    }
    
    @IBAction func cabeButton(_ sender: Any) {
        letterLabel.text = "CABE"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "CA", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "BE", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "CABE", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }

    
    
    @IBAction func wortelButton(_ sender: Any) {
        letterLabel.text = "WORTEL"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "WOR", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "TEL", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "WORTEL", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }

    
    
}



















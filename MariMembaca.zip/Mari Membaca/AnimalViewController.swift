//
//  AnimalViewController.swift
//  Mari Membaca
//
//  Created by Mohammad Rahimyarza Bagagarsyah on 07/06/18.
//  Copyright © 2018 Mohammad Rahimyarza Bagagarsyah. All rights reserved.
//

import UIKit
import AVFoundation

class AnimalViewController: UIViewController {
    
    @IBOutlet weak var letterLabel: UILabel!
    var audioPlayer = AVAudioPlayer()
    var audioPlayer1 = AVAudioPlayer()
    var audioPlayer2 = AVAudioPlayer()
    override func viewDidLoad() {
        super.viewDidLoad()
        letterLabel.text = ""
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func anjingButton(_ sender: Any) {
        letterLabel.text = "ANJING"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "AN", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "JING", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "ANJING", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }
    
    @IBAction func babiButton(_ sender: Any) {
        letterLabel.text = "BABI"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "BA", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "BI", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "BABI", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }
    
    @IBAction func kucingButton(_ sender: Any) {
        letterLabel.text = "KUCING"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "KU", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "CING", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "KUCING", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }
    
    @IBAction func sapiButton(_ sender: Any) {
        letterLabel.text = "SAPI"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "SA", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "PI", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "SAPI", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }
    
    @IBAction func monyetButton(_ sender: Any) {
        letterLabel.text = "MONYET"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "MO", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "NYET", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "MONYET", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

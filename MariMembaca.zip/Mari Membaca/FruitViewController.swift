//
//  FruitViewController.swift
//  Mari Membaca
//
//  Created by Mohammad Rahimyarza Bagagarsyah on 07/06/18.
//  Copyright © 2018 Mohammad Rahimyarza Bagagarsyah. All rights reserved.
//

import UIKit
import AVFoundation

class FruitViewController: UIViewController {
    @IBOutlet weak var letterLabel: UILabel!
    var audioPlayer = AVAudioPlayer()
    var audioPlayer1 = AVAudioPlayer()
    var audioPlayer2 = AVAudioPlayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        letterLabel.text = ""
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func anggurButton(_ sender: Any) {
        letterLabel.text = "ANGGUR"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "ANG", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "GUR", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "ANGGUR", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }

    
    @IBAction func apelButton(_ sender: Any) {
        letterLabel.text = "APEL"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "a", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "PEL", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "APEL", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }
    
    @IBAction func ceriButton(_ sender: Any) {
        letterLabel.text = "CERI"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "CE", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "RI", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "CERI", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }
    
    @IBAction func jerukButton(_ sender: Any) {
        letterLabel.text = "JERUK"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "JE", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "RUK", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "JERUK", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }
    
    @IBAction func pisangButton(_ sender: Any) {
        letterLabel.text = "PISANG"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "PI", ofType: "mp3")!))
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "SANG", ofType: "mp3")!))
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "PISANG", ofType: "mp3")!))
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer1.prepareToPlay()
        audioPlayer2.prepareToPlay()
        audioPlayer.play()
        audioPlayer1.play(atTime: audioPlayer1.deviceCurrentTime + 1.5)
        audioPlayer2.play(atTime: audioPlayer2.deviceCurrentTime + 3)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

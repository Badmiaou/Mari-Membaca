//
//  WordViewController.swift
//  Mari Membaca
//
//  Created by Mohammad Rahimyarza Bagagarsyah on 07/06/18.
//  Copyright © 2018 Mohammad Rahimyarza Bagagarsyah. All rights reserved.
//

import UIKit
import AVFoundation

class WordViewController: UIViewController {

    @IBOutlet weak var letterLabel: UILabel!
    var audioPlayer = AVAudioPlayer()
    override func viewDidLoad() {
        super.viewDidLoad()
        letterLabel.text = ""
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func aButton(_ sender: Any) {
        letterLabel.text = "A"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "a", ofType: "mp3")!))
            
        } catch  {
            print(error)
            
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
        
    }
    @IBAction func bButton(_ sender: Any) {
        letterLabel.text = "B"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "b", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    @IBAction func cButton(_ sender: Any) {
        letterLabel.text = "C"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "c", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    @IBAction func dButton(_ sender: Any) {
        letterLabel.text = "D"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "d", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    @IBAction func eButton(_ sender: Any) {
        letterLabel.text = "E"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "e", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    @IBAction func fButton(_ sender: Any) {
        letterLabel.text = "F"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "f", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    @IBAction func gButton(_ sender: Any) {
        letterLabel.text = "G"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "g", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    @IBAction func hButton(_ sender: Any) {
        letterLabel.text = "H"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "h", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func iButton(_ sender: Any) {
        letterLabel.text = "I"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "i", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func jButton(_ sender: Any) {
        letterLabel.text = "J"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "j", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func kButton(_ sender: Any) {
        letterLabel.text = "K"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "k", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func lButton(_ sender: Any) {
        letterLabel.text = "L"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "l", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func mButton(_ sender: Any) {
        letterLabel.text = "M"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "m", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func nButton(_ sender: Any) {
        letterLabel.text = "N"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "n", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    @IBAction func oButton(_ sender: Any) {
        letterLabel.text = "O"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "o", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    @IBAction func pButton(_ sender: Any) {
        letterLabel.text = "P"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "p", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func qButton(_ sender: Any) {
        letterLabel.text = "Q"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "q", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    @IBAction func rButton(_ sender: Any) {
        letterLabel.text = "R"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "r", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    @IBAction func sButton(_ sender: Any) {
        letterLabel.text = "S"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "s", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    @IBAction func tButton(_ sender: Any) {
        letterLabel.text = "T"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "t", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func uButton(_ sender: Any) {
        letterLabel.text = "U"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "u", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func vButton(_ sender: Any) {
        letterLabel.text = "V"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "v", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func wButton(_ sender: Any) {
        letterLabel.text = "W"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "w", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func xButton(_ sender: Any) {
        letterLabel.text = "X"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "x", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func yButton(_ sender: Any) {
        letterLabel.text = "Y"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "y", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    @IBAction func zButton(_ sender: Any) {
        letterLabel.text = "Z"
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "z", ofType: "mp3")!))
        } catch  {
            print(error)
        }
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    
    
    
    
}
    

































